<template>
  <div>
    <tv-navigation />
    <template v-if="loading">
      <tv-spinner />
    </template>

    <template v-else>
      <h1>People</h1>
      <v-container class="pa-4 text-center">
        <v-row class="fill-height" align="center" justify="left">
          <template v-for="item in people">
            <v-col :key="item.name" cols="12" md="4">
              <v-hover v-slot="{ hover }">
                <v-card
                  :elevation="hover ? 12 : 2"
                  :class="{ 'on-hover': hover }"
                >
                  <v-card-title class="text-h6">
                    <v-row
                      class="fill-height flex-column"
                      justify="space-between"
                    >
                      <p class="ml-3 mt-3 subheading text-left">
                        {{ item.name }}
                      </p>
                      <div>
                        <p class="ml-3 text-body-1 font-weight-bold text-left">
                          Hair color: {{ item.hair_color }}
                        </p>
                        <p class="ml-3 text-body-1 font-weight-bold text-left">
                          Eye color: {{ item.eye_color }}
                        </p>
                        <p class="mr-3 text-body-1 font-weight-bold text-right">
                          <v-btn elevation="2" @click="editItem(item.name)">
                            Edit
                          </v-btn>
                        </p>
                      </div>
                    </v-row>
                  </v-card-title>
                </v-card>
              </v-hover>
            </v-col>
          </template>
        </v-row>
      </v-container>
    </template>
  </div>
</template>

<script>
// Core
import Component, { mixins } from 'vue-class-component'

// Vuex
import { State } from 'vuex-class'

// Mixins
import TvLoading from '@/mixins/loading'

// Component imports
import TvNavigation from '@/components/navigation/Navigation'
import TvSpinner from '@/components/spinner/Spinner'

/**
 *  TvPeople
 *
 *  @desc - SWAPI People Page
 *
 *  @author Front End Dev @Certipath
 *
 *  Mon Mar 7 09:00:00 MST 2022
 */
@Component({
  layout: 'default',
  components: {
    TvNavigation,
    TvSpinner
  }
})
export default class TvPeople extends mixins(TvLoading) {
  // Data
  transparent = 'rgba(255, 255, 255, 0)'
  apiCount = 0

  @State('people', { namespace: 'peopleState' })
  people

  created() {
    // get data
    this.retrieveData()
  }

  // Methods
  async retrieveData() {
    // getPeople API call
    await this.getPeople()

    // getStarships API call
    await this.getStarships()

    // getPlanets API call
    await this.getPlanets()
  }

  getPeople() {
    this.$api.getPeople().then(response => {
      if (response) {
        this.hideSpinner()
        const people = response.results
        console.log('people: ', people)
        // Store the response
        this.$store.commit('peopleState/setPeople', people)
      } else {
        console.warn('No people data available.')
      }
    })
  }

  getStarships() {
    this.$api.getStarships().then(response => {
      if (response) {
        this.hideSpinner()
        const starships = response.results
        console.log('starships: ', starships)
        // Store the response
        this.$store.commit('starshipsState/setStarships', starships)
      } else {
        console.warn('No starship data available.')
      }
    })
  }

  getPlanets() {
    this.$api.getPlanets().then(response => {
      if (response) {
        this.hideSpinner()
        const planets = response.results
        console.log('planets: ', planets)
        // Store the response
        this.$store.commit('planetsState/setPlanets', planets)
      } else {
        console.warn('No planets data available.')
      }
    })
  }

  hideSpinner() {
    this.apiCount += 1
    if (this.apiCount === 3) {
      this.$store.commit('appState/setloading', false)
    }
  }

  editItem(item) {
    console.log(item)
    this.$router.push('/')
  }

  isObjectEmpty(value) {
    return (
      Object.prototype.toString.call(value) === '[object Object]' &&
      JSON.stringify(value) === '{}'
    )
  }
}
</script>

<style lang="postcss">
.v-card {
  transition: opacity 0.4s ease-in-out;
}

.v-card:not(.on-hover) {
  opacity: 0.6;
}
</style>
