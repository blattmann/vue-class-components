import registerRequireContextHook from 'babel-plugin-require-context-hook/register'
registerRequireContextHook()
