<template>
  <v-app>
    <v-container fluid>
      <v-fade-transition mode="out-in">
        <nuxt />
      </v-fade-transition>
    </v-container>
  </v-app>
</template>

<script>
export default {}
</script>
