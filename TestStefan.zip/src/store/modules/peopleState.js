// Vuex
import { Module, Mutation, VuexModule } from 'vuex-module-decorators'

// const peopleObject = {}

/**
 *  @desc -
 *
 *  @author Front End Dev @Certipath
 *
 * Mar 09 2022 16:00:00
 */
@Module({
  stateFactory: true,
  namespaced: true,
  name: 'peopleState'
})
export default class PeopleModule extends VuexModule {
  // @Mutation
  // init(data) {
  //   this.people = data
  // }

  // @Mutation
  // reset() {
  //   this.people = { ...this.peopleInitialState }
  // }

  @Mutation
  setPeople(data) {
    this.people = data
  }

  peopleInitialState = {}

  people = { ...this.peopleInitialState }
}
